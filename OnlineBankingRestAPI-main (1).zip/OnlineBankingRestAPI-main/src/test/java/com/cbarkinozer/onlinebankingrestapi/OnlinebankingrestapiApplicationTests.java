package com.cbarkinozer.onlinebankingrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinebankingrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
