package com.cbarkinozer.onlinebankingrestapi.app.loa.enums;

public enum LoaLoanStatusType {
    CONTINUING,
    LATE,
    PAID,
}
