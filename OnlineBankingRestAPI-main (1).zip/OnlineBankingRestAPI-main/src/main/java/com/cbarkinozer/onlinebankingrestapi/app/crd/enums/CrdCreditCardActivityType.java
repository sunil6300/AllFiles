package com.cbarkinozer.onlinebankingrestapi.app.crd.enums;

public enum CrdCreditCardActivityType {
    SPEND,
    REFUND,
    PAYMENT,
}
