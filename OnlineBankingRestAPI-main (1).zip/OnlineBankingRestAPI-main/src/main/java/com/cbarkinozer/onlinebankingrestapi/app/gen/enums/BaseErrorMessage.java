package com.cbarkinozer.onlinebankingrestapi.app.gen.enums;

public interface BaseErrorMessage {

    String getMessage();
    String getDetailMessage();
}
