package com.cbarkinozer.onlinebankingrestapi.app.gen.entity;

public interface BaseModel {

    Long getId();
}
