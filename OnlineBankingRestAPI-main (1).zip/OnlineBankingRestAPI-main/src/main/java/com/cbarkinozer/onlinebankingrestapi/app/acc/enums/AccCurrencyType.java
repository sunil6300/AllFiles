package com.cbarkinozer.onlinebankingrestapi.app.acc.enums;

public enum AccCurrencyType {
    TL,
    USD,
    EURO
}
