package com.cbarkinozer.onlinebankingrestapi.app.acc.enums;

public enum AccAccountActivityType {
    WITHDRAW,
    DEPOSIT,
    SEND,
    GET,
}
