package com.cbarkinozer.onlinebankingrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinebankingrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinebankingrestapiApplication.class, args);
	}

}
