package com.cbarkinozer.onlinebankingrestapi.app.acc.enums;

public enum AccAccountType {
    DRAWING,
    DEPOSIT
}
