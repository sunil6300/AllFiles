package com.cbarkinozer.onlinebankingrestapi.app.gen.enums;

public enum GenStatusType {
    ACTIVE,
    PASSIVE
}
